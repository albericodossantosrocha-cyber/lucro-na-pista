# Lucro na Pista

App Android para quem faz entregas de carro por aplicativo (Uber, 99, Lalamove, iFood, Rappi, Keeta, Shopee…).
Tudo fica salvo no próprio celular: sem login, sem servidor.

## O que tem
- **Vale?** – calculadora de corrida: verde (aceitar), amarelo (no limite) ou vermelho (recusar), contando o km até a coleta e a volta vazia.
- **Turno** – cronômetro com pausa, km por GPS ou odômetro, corrida lançada em 2 toques (valor + app), gorjetas e gastos.
- **Cofrinho** – ao encerrar o turno separa sozinho: contas fixas do dia, manutenção por km, combustível, emergência e dias parados. Mostra o "seu de verdade" e os alertas (aluguel, troca de óleo etc.).
- **Painel** – semana/mês, meta mensal com projeção, ranking por app, mapa de horários e melhores regiões.
- **Mais** – configurações, dicas e backup/exportação (CSV e JSON).

## Como gerar o APK (GitHub Actions)
1. Crie um repositório no GitHub (ex.: `lucro-na-pista`) e envie **todos** os arquivos desta pasta, inclusive `.github/` e `assinatura/`.
2. O build roda sozinho a cada envio para `main`. Ou abra **Actions › Gerar APK › Run workflow**.
3. Ao terminar, abra a execução e baixe o artefato **lucro-na-pista-apk** (vem em .zip; dentro está o `lucro-na-pista.apk`).
4. No celular, abra o APK e permita "instalar apps desconhecidos" para o navegador/gerenciador de arquivos.

### Sobre o erro de conflito na instalação
O APK é sempre assinado com a mesma chave (`assinatura/lucro-na-pista.keystore`) e a versão sobe a cada build, então as próximas versões instalam **por cima**, sem perder dados.
Se um dia aparecer "conflito com pacote existente", é porque havia uma versão assinada com outra chave: faça **backup** em Mais › Backup, desinstale, instale a nova e restaure o backup.

> A chave e a senha estão no repositório para facilitar o uso pessoal. Se for publicar na Play Store, gere uma chave nova e guarde-a como *secret*.

## Testar no navegador
Abra `www/index.html` no Chrome (de preferência pelo celular). Para hospedar (ex.: Netlify), publique só a pasta `www`.

## Estrutura
```
www/index.html               o app inteiro (HTML único)
capacitor.config.json        empacotamento Android
scripts/preparar-android.sh  permissões de GPS, assinatura fixa, versão e ícones
scripts/icones.py            gera ícones e tela de abertura
.github/workflows/android.yml build do APK
```
