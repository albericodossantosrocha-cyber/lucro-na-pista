"""Gera ícones e telas de abertura do Lucro na Pista dentro de android/app/src/main/res."""
import os, sys
from PIL import Image, ImageDraw

LARANJA = (255, 138, 61, 255)
ESCURO = (36, 16, 2, 255)
CLARO = (255, 178, 127, 255)
FUNDO = (11, 14, 19, 255)


def desenha_estrada(d, x0, y0, s):
    """Estrada com faixa tracejada dentro do quadrado (x0, y0, s)."""
    def P(x, y):
        return (x0 + x * s, y0 + y * s)
    d.polygon([P(.353, .882), P(.447, .147), P(.553, .147), P(.647, .882)], fill=ESCURO)
    w = max(2, int(s * .06))
    for a, b in [(.235, .353), (.47, .588), (.705, .823)]:
        d.line([P(.5, a), P(.5, b)], fill=CLARO, width=w)


def logo(size, redondo=False, so_frente=False):
    im = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    big = size * 4
    im = Image.new('RGBA', (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if so_frente:
        # ícone adaptativo: desenho dentro da zona segura (66/108)
        m = big * 21 / 108
        desenha_estrada(d, m, m, big - 2 * m)
    else:
        if redondo:
            d.ellipse([0, 0, big - 1, big - 1], fill=LARANJA)
            m = big * .14
        else:
            d.rounded_rectangle([0, 0, big - 1, big - 1], radius=big * .22, fill=LARANJA)
            m = big * .08
        desenha_estrada(d, m, m, big - 2 * m)
    return im.resize((size, size), Image.LANCZOS)


DENS = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}


def main(res):
    for nome, f in DENS.items():
        pasta = os.path.join(res, 'mipmap-' + nome)
        os.makedirs(pasta, exist_ok=True)
        logo(int(48 * f)).save(os.path.join(pasta, 'ic_launcher.png'))
        logo(int(48 * f), redondo=True).save(os.path.join(pasta, 'ic_launcher_round.png'))
        logo(int(108 * f), so_frente=True).save(os.path.join(pasta, 'ic_launcher_foreground.png'))
    vals = os.path.join(res, 'values')
    os.makedirs(vals, exist_ok=True)
    with open(os.path.join(vals, 'ic_launcher_background.xml'), 'w') as fh:
        fh.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FF8A3D</color>\n</resources>\n')
    # telas de abertura: troca cada splash.png existente mantendo o tamanho
    n = 0
    for raiz, _, arqs in os.walk(res):
        for a in arqs:
            if a == 'splash.png':
                p = os.path.join(raiz, a)
                w, h = Image.open(p).size
                sp = Image.new('RGBA', (w, h), FUNDO)
                lado = int(min(w, h) * .28)
                lg = logo(lado)
                sp.alpha_composite(lg, ((w - lado) // 2, (h - lado) // 2))
                sp.convert('RGB').save(p)
                n += 1
    print(f'ícones gerados; {n} telas de abertura trocadas')


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'android/app/src/main/res')
