#!/usr/bin/env bash
# Ajusta o projeto Android gerado pelo Capacitor: permissões, assinatura fixa, versão e ícones.
set -euo pipefail
APP=android/app
MAN=$APP/src/main/AndroidManifest.xml

# 1) Permissões de localização (km pelo GPS e aviso de carro em movimento)
if ! grep -q ACCESS_FINE_LOCATION "$MAN"; then
  sed -i 's#<application#<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />\n    <uses-feature android:name="android.hardware.location.gps" android:required="false" />\n\n    <application#' "$MAN"
fi

# 2) Assinatura sempre com a MESMA chave + versão crescente a cada build
#    (assim o APK novo instala por cima do antigo, sem erro de conflito)
cat >> $APP/build.gradle <<'GRADLE'

android {
    signingConfigs {
        fixa {
            storeFile file('../../assinatura/lucro-na-pista.keystore')
            storePassword 'lucronapista'
            keyAlias 'lucro'
            keyPassword 'lucronapista'
        }
    }
    defaultConfig {
        versionCode((System.getenv('GITHUB_RUN_NUMBER') ?: '1').toInteger())
        versionName "1.0." + (System.getenv('GITHUB_RUN_NUMBER') ?: '0')
    }
    buildTypes {
        release { signingConfig signingConfigs.fixa; minifyEnabled false }
        debug { signingConfig signingConfigs.fixa }
    }
}
GRADLE

# 3) Ícones e tela de abertura
python3 scripts/icones.py $APP/src/main/res
echo "Projeto Android preparado."
